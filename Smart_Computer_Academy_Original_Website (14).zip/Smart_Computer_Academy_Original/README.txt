SMART COMPUTER ACADEMY — EMPLOYEE SALARY MANAGEMENT

Owner / Admin label: Sir Jahanzaib

OPEN THE WEBSITE
1. Download and extract the ZIP.
2. Open the extracted folder.
3. Double-click index.html.

FEATURES
- Add employee name and department/sector.
- Enter each employee's monthly salary in PKR.
- Select a bank and payment method.
- Track pending/paid status.
- View monthly salary totals by department.
- Search and filter employees.
- Export records to CSV.

IMPORTANT LIMITATIONS
This is a working front-end demo. Data is saved in localStorage in the current browser on this computer.
It is not a secure hosted website, does not have real administrator authentication, and does not transfer money to banks.
For real staff payroll, use a secure database, authentication, backups and appropriate privacy protections.
Bank options are labels for record keeping only; verify availability and suitability with the actual bank.
