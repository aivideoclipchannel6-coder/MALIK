const $=id=>document.getElementById(id);
const KEY="sca_original_payroll_v2";
let employees=[];
try{employees=JSON.parse(localStorage.getItem(KEY)||"[]")}catch(e){employees=[]}
const currentMonth=new Date().toISOString().slice(0,7);
$("today").textContent=new Date().toLocaleDateString("en-PK",{day:"numeric",month:"short",year:"numeric"});
$("year").textContent=new Date().getFullYear();
$("salaryMonth").value=currentMonth;
const fmt=n=>"Rs "+Number(n||0).toLocaleString("en-PK");
const monthName=m=>{if(!m)return "—";let [y,mo]=m.split("-");return new Date(Number(y),Number(mo)-1,1).toLocaleDateString("en-PK",{month:"short",year:"numeric"})};
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function save(){localStorage.setItem(KEY,JSON.stringify(employees));render()}
function render(){
 const q=$("search").value.trim().toLowerCase(), dept=$("filterDept").value;
 const visible=employees.filter(e=>(!q||(e.name+" "+e.department).toLowerCase().includes(q))&&(!dept||e.department===dept));
 const total=employees.reduce((s,e)=>s+Number(e.salary),0);
 const paid=employees.filter(e=>e.status==="Paid"&&e.month===currentMonth).reduce((s,e)=>s+Number(e.salary),0);
 $("count").textContent=employees.length;$("payrollTotal").textContent=fmt(total);$("paidTotal").textContent=fmt(paid);$("pendingTotal").textContent=fmt(total-paid);
 $("empty").classList.toggle("hidden",visible.length>0);
 $("employeeRows").innerHTML=visible.map(e=>`<tr><td><div class="emp-name">${esc(e.name)}</div><div class="emp-id">Staff ID: ${esc(e.id)}</div></td><td>${esc(e.department)}</td><td><b>${fmt(e.salary)}</b><div class="emp-id">${esc(monthName(e.month))}</div></td><td>${esc(e.bank||"Not selected")}<div class="emp-id">${esc(e.method)}</div></td><td><span class="pill ${e.status==="Paid"?"paid":"pending"}">${e.status==="Paid"?"Paid":"Pending"}</span></td><td>${e.status==="Paid"?"":`<button class="action" data-pay="${esc(e.id)}">Mark Paid</button>`}<button class="action delete" data-delete="${esc(e.id)}">Delete</button></td></tr>`).join("");
 const groups={};employees.forEach(e=>{groups[e.department]=(groups[e.department]||0)+Number(e.salary)});
 const max=Math.max(1,...Object.values(groups));
 $("sectorSummary").innerHTML=Object.keys(groups).length?Object.entries(groups).sort((a,b)=>b[1]-a[1]).map(([d,v])=>`<div class="sector"><span>${esc(d)}</span><strong>${fmt(v)}</strong><small>Monthly total · ${employees.filter(e=>e.department===d).length} employee(s)</small><div class="sector-track"><i style="width:${Math.max(3,v/max*100)}%"></i></div></div>`).join(""):'<div class="empty">Add employees to see the salary summary by sector.</div>';
 const records=employees.filter(e=>e.status==="Paid");
 $("paymentRows").innerHTML=records.map(e=>`<tr><td>${esc(monthName(e.month))}</td><td>${esc(e.name)}</td><td>${esc(e.department)}</td><td>${fmt(e.salary)}</td><td>${esc(e.bank||"Not selected")} / ${esc(e.method)}</td><td>${esc(e.paidDate||"—")}</td></tr>`).join("");
 $("emptyPayments").classList.toggle("hidden",records.length>0);
}
$("addBtn").onclick=()=>{$("employeeForm").classList.remove("hidden");$("name").focus()};
$("cancelBtn").onclick=()=>{$("employeeForm").reset();$("salaryMonth").value=currentMonth;$("employeeForm").classList.add("hidden")};
$("employeeForm").onsubmit=e=>{e.preventDefault();const emp={id:String(Date.now()).slice(-7),name:$("name").value.trim(),department:$("department").value,salary:Number($("salary").value),bank:$("bank").value,method:$("method").value,month:$("salaryMonth").value,status:"Pending",paidDate:""};if(!emp.name||!emp.department||!emp.month||emp.salary<0)return;employees.push(emp);save();$("employeeForm").reset();$("salaryMonth").value=currentMonth;$("employeeForm").classList.add("hidden")};
$("search").addEventListener("input",render);$("filterDept").addEventListener("change",render);
document.addEventListener("click",e=>{const pay=e.target.dataset.pay,del=e.target.dataset.delete;if(pay){const emp=employees.find(x=>x.id===pay);if(emp){emp.status="Paid";emp.paidDate=new Date().toLocaleDateString("en-PK");save()}}if(del&&confirm("Delete this employee record?")){employees=employees.filter(x=>x.id!==del);save()}});
$("exportBtn").onclick=()=>{const rows=[["Employee ID","Name","Department","Salary PKR","Bank","Payment Method","Month","Status","Paid Date"],...employees.map(e=>[e.id,e.name,e.department,e.salary,e.bank,e.method,e.month,e.status,e.paidDate])];const csv=rows.map(r=>r.map(v=>'"'+String(v??"").replace(/"/g,'""')+'"').join(",")).join("\r\n");const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="smart-computer-academy-payroll.csv";a.click();URL.revokeObjectURL(a.href)};
render();
